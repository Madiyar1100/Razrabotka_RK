package com.example.registerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail: EditText = findViewById(R.id.loginEmail)
        val etPassword: EditText = findViewById(R.id.loginPassword)
        val btnLogin: Button = findViewById(R.id.btnLoginUser)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            if(email == UserData.email && password == UserData.password) {
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Қате енгізу", Toast.LENGTH_SHORT).show()
            }
        }
    }
}