package com.example.registerapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val etName: EditText = findViewById(R.id.editName)
        val etEmail: EditText = findViewById(R.id.editEmail)
        val etPassword: EditText = findViewById(R.id.editPassword)
        val btnSave: Button = findViewById(R.id.saveProfile)

        etName.setText(UserData.name)
        etEmail.setText(UserData.email)
        etPassword.setText(UserData.password)

        btnSave.setOnClickListener {
            val name = etName.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            if(name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Барлық өрістерді толтырыңыз", Toast.LENGTH_SHORT).show()
            } else {
                UserData.name = name
                UserData.email = email
                UserData.password = password
                Toast.makeText(this, "Деректер жаңартылды", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}