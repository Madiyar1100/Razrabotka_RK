package com.example.registerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val tvName: TextView = findViewById(R.id.profileName)
        val tvEmail: TextView = findViewById(R.id.profileEmail)
        val btnEdit: Button = findViewById(R.id.btnEdit)

        tvName.text = "Аты: ${UserData.name}"
        tvEmail.text = "Email: ${UserData.email}"

        btnEdit.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }
    }
}